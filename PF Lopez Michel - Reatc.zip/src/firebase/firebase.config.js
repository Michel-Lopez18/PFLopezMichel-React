// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBYV79xVXaXbpuQswj_QvjJnps88p7dFC8",
  authDomain: "macco-51d78.firebaseapp.com",
  projectId: "macco-51d78",
  storageBucket: "macco-51d78.appspot.com",
  messagingSenderId: "912777099096",
  appId: "1:912777099096:web:dc769e91905f82e93e972d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);